# Stone Scan — Identificador de Pedras

Aplicativo web/PWA mobile-first para catálogo, câmera, análise demonstrativa, favoritos, histórico, câmbio e assistente por texto/voz.

## Importante
A identificação por foto é estimativa. Uma fotografia não certifica espécie, autenticidade, composição, qualidade ou valor comercial. Para confirmação, procure gemólogo, geólogo ou laboratório especializado.

## Executar
Sirva a pasta por HTTPS ou localhost. A câmera do navegador normalmente exige contexto seguro (HTTPS) ou localhost.

Exemplo:
`python3 -m http.server 8080`

Abra `http://localhost:8080` no computador. Para usar a câmera no celular, publique em um host HTTPS.

## IA segura
Não coloque uma API key secreta no `index.html`, `app.js`, GitHub ou PWA. A configuração do app aceita somente `API URL`, que deve apontar para seu próprio backend. O backend guarda a chave como variável de ambiente e encaminha somente as requisições necessárias para o provedor de IA.

O frontend envia a fotografia ao backend somente depois de pedir confirmação ao usuário.

### Contrato sugerido do backend
POST `/vision`
```json
{"image":"data:image/jpeg;base64,..."}
```
Resposta:
```json
{"id":"ametista","nome":"Ametista","confidence":72,"raridade":"Incomum","possiveis":[{"nome":"Ametista","p":72}]}
```

## Cotação
O app usa uma API pública de câmbio para consulta. Se estiver indisponível, informa o erro em vez de inventar uma cotação.

## Imagens
Os registros iniciais apontam para imagens do Wikimedia Commons e exibem a fonte. Se uma imagem falhar, o cartão mostra `Imagem indisponível` e não substitui por foto de outra pedra.

## Expansão
Adicione objetos ao `data/stones.js`. O catálogo foi estruturado para crescer para centenas ou milhares de registros.

## Sobre “99% de acerto”
Nenhum aplicativo pode garantir 99% de identificação correta de qualquer pedra usando somente uma fotografia. O sistema deve retornar probabilidades/possibilidades e indicar quando é necessária análise profissional.
